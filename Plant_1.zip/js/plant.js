// JavaScript Document
$(document).ready(function() {
			$height = $(window).height();
			$width = $(window).width();
			
			$('#iwrapper').css({height:+$height+'px'});
			$('#iwrapper').css({width:+$width+'px'});
			$('#index_plant').css({margin:'0 0 0 '+(($width / 2)-156.5)+'px'});
			$('#logo').css({margin:'75px 0 0 '+(($width / 2)-208.5)+'px'});
			
});
